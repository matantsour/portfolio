{{ config(
    materialized='table',
    alias='q5_households_per_income'
) }}

WITH income_buckets AS (
  SELECT geo_id, '0-14,999' AS income_bucket, SUM(income_10000_14999) AS households
  FROM `bigquery-public-data.census_bureau_acs.state_2020_5yr`
  GROUP BY geo_id
  UNION ALL
  SELECT geo_id, '15,000-24,999', SUM(income_15000_19999)+SUM(income_20000_24999)
  FROM `bigquery-public-data.census_bureau_acs.state_2020_5yr`
  GROUP BY geo_id
  UNION ALL
  SELECT geo_id, '25,000-49,999', SUM(income_25000_29999)+SUM(income_30000_34999)+SUM(income_35000_39999)+SUM(income_40000_44999)+SUM(income_45000_49999)
  FROM `bigquery-public-data.census_bureau_acs.state_2020_5yr`
  GROUP BY geo_id
  UNION ALL
  SELECT geo_id, '50,000-99,999', SUM(income_50000_59999)+SUM(income_60000_74999)+SUM(income_75000_99999)
  FROM `bigquery-public-data.census_bureau_acs.state_2020_5yr`
  GROUP BY geo_id
  UNION ALL
  SELECT geo_id, '100,000+', SUM(income_100000_124999)+SUM(income_125000_149999)+SUM(income_150000_199999)+SUM(income_200000_or_more)
  FROM `bigquery-public-data.census_bureau_acs.state_2020_5yr`
  GROUP BY geo_id
),
state_income_totals AS (
  SELECT geo_id, SUM(households) AS total_households
  FROM income_buckets
  GROUP BY geo_id
),
total_total AS (
  SELECT SUM(households) AS total_households_us
  FROM income_buckets
)

SELECT
  s.state_name,
  i.income_bucket,
  i.households,
  ROUND(SAFE_DIVIDE(i.households, t.total_households),4) AS pct_of_state_households,
  ROUND(SAFE_DIVIDE(i.households, (SELECT total_households_us FROM total_total)),8) AS pct_of_total
FROM income_buckets AS i
JOIN state_income_totals AS t
  ON i.geo_id = t.geo_id
JOIN `bigquery-public-data.geo_us_boundaries.states` AS s
  ON i.geo_id = s.geo_id
ORDER BY s.state_name, i.income_bucket
