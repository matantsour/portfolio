{{ config(
    materialized='table',
    alias='q9_jobs_over_time'
) }}

WITH jobs_per_category AS (
  SELECT
    DATE(created) AS created_date,
    search_state AS state_name,
    category_label,
    COUNT(*) AS jobs_in_category
  FROM {{ source('ravendataanalyst', 'adzuna_jobs') }}
  GROUP BY created_date, state_name, category_label
)

SELECT
  created_date,
  state_name,
  SUM(jobs_in_category) AS total_jobs,
  ROUND(AVG(jobs_in_category),2) AS avg_jobs_per_category
FROM jobs_per_category
GROUP BY created_date, state_name
ORDER BY created_date, state_name
