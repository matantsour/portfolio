{{ config(
    materialized='table',
    alias='q2_employment_sectors'
) }}

SELECT
  s.state_name,
  SUM(e.employed_agriculture_forestry_fishing_hunting_mining) AS agri_employed,
  SUM(e.employed_arts_entertainment_recreation_accommodation_food) AS arts_food_employed,
  SUM(e.employed_education_health_social) AS edu_health_employed,
  SUM(e.employed_finance_insurance_real_estate) AS finance_employed,
  SUM(e.employed_manufacturing) AS manufacturing_employed,
  SUM(e.employed_retail_trade) AS retail_employed,
  SUM(e.employed_pop) AS total_employed,
  ROUND(SAFE_DIVIDE(SUM(e.employed_education_health_social), SUM(e.employed_pop)), 2) AS pct_edu_health
FROM `bigquery-public-data.census_bureau_acs.state_2020_5yr` AS e
JOIN `bigquery-public-data.geo_us_boundaries.states` AS s
  ON e.geo_id = s.geo_id
GROUP BY s.state_name
ORDER BY pct_edu_health DESC
