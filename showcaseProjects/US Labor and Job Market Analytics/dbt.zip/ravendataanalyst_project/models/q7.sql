{{ config(
    materialized='table',
    alias='q7_jobs_by_category'
) }}

SELECT
    search_state AS state_name,
    category_label,
    COUNT(*) AS jobs_count
FROM {{ source('ravendataanalyst', 'adzuna_jobs') }} AS a
GROUP BY search_state, category_label
ORDER BY state_name, jobs_count DESC
