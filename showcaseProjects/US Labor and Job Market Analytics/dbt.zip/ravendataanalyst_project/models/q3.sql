{{ config(
    materialized='table',
    alias='q3_income_rent_housing'
) }}

SELECT
  s.state_name,
  ROUND(AVG(c.median_income),2) AS avg_median_income,
  ROUND(AVG(c.median_rent)*12,2) AS avg_median_yearly_rent,
  ROUND(SAFE_DIVIDE(AVG(c.median_rent)*12, AVG(c.median_income)),4) AS avg_rent_to_income_ratio,
  ROUND(AVG(c.owner_occupied_housing_units_median_value),2) AS avg_owner_occupied_housing_value
FROM `bigquery-public-data.census_bureau_acs.county_2020_5yr` AS c
JOIN `bigquery-public-data.geo_us_boundaries.states` AS s
  ON c.geo_id LIKE CONCAT(s.geo_id, '%')
WHERE c.median_income IS NOT NULL
  AND c.median_income > 0
  AND c.median_rent > 0
  AND c.owner_occupied_housing_units_median_value > 0
GROUP BY s.state_name
ORDER BY avg_owner_occupied_housing_value DESC
LIMIT 50
