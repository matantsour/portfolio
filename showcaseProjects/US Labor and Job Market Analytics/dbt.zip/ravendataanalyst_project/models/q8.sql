{{ config(
    materialized='table',
    alias='q8_job_density_base'
) }}

SELECT
    state_name,
    total_jobs,
    pop_25_64
FROM {{ source('ravendataanalyst', 'adzuna_jobs') }}