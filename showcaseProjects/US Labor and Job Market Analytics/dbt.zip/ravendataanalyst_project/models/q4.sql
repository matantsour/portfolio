{{ config(
    materialized='table',
    alias='q4_commute_remote'
) }}

SELECT
  s.state_name,
  ROUND(SAFE_DIVIDE(SUM(c.aggregate_travel_time_to_work), SUM(c.workers_16_and_over)),2) AS avg_travel_time_to_work,
  SUM(c.commuters_drove_alone) AS total_commuters_drove_alone,
  SUM(c.commuters_by_public_transportation) AS total_commuters_public_transport,
  ROUND(SAFE_DIVIDE(SUM(c.worked_at_home), SUM(c.workers_16_and_over)),4) AS pct_remote_avg
FROM `bigquery-public-data.census_bureau_acs.county_2020_5yr` AS c
JOIN `bigquery-public-data.geo_us_boundaries.states` AS s
  ON c.geo_id LIKE CONCAT(s.geo_id, '%')
WHERE c.aggregate_travel_time_to_work IS NOT NULL
GROUP BY s.state_name
ORDER BY pct_remote_avg DESC, avg_travel_time_to_work DESC
