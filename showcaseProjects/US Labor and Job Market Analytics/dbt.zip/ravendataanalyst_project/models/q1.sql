{{ config(
    materialized='table',
    alias='q1_education_labor'
) }}

SELECT
  s.state_name,
  SUM(c.total_pop) AS total_pop,
  SUM(c.pop_25_64) AS pop_25_64,
  SUM(c.bachelors_degree_or_higher_25_64) AS bachelors_degree_or_higher_25_64,
  ROUND(SAFE_DIVIDE(SUM(c.bachelors_degree_or_higher_25_64), SUM(c.pop_25_64)), 4) AS pct_bachelors_plus,
  ROUND(SAFE_DIVIDE(SUM(c.civilian_labor_force), SUM(c.pop_16_over)), 4) AS labor_force_participation
FROM `bigquery-public-data.census_bureau_acs.county_2020_5yr` AS c
JOIN `bigquery-public-data.geo_us_boundaries.states` AS s
  ON c.geo_id LIKE CONCAT(s.geo_id, '%')
WHERE c.pop_25_64 > 10000
GROUP BY s.state_name
ORDER BY pct_bachelors_plus DESC
