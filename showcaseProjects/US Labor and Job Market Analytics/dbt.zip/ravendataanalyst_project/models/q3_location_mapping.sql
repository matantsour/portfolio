{{ config(
    materialized='table',
    alias='q3_location_mapping'
) }}

SELECT
  q.*,
  s.state_geom
FROM {{ ref('q3') }} AS q
LEFT JOIN `ravendataanalyst.dbo.state_location_mapping` AS s
  ON s.state_name = q.state_name
