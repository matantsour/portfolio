{{ config(
    materialized='table',
    alias='q6_total_jobs'
) }}

SELECT
    l.state_name,
    COUNT(a.id) AS total_jobs,
    l.pop_25_64,
    l.bachelors_degree_or_higher_25_64,
    l.pct_bachelors_plus
FROM {{ source('ravendataanalyst', 'adzuna_jobs') }} AS a
JOIN {{ ref('q1') }} AS l
    ON a.search_state = l.state_name
GROUP BY l.state_name, l.pop_25_64, l.bachelors_degree_or_higher_25_64, l.pct_bachelors_plus
ORDER BY total_jobs DESC
