{{ config(
    materialized='table',
    alias='q2_employment_sectors_unpivot'
) }}


SELECT
  state_name,
  industry,
  employees
FROM {{ ref('q2') }}
UNPIVOT (
  employees FOR industry IN (
    agri_employed,
    arts_food_employed,
    edu_health_employed,
    finance_employed,
    manufacturing_employed,
    retail_employed
  )
)
